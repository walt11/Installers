﻿Imports Twilio
Imports Twilio.Rest.Api.V2010.Account
Imports Twilio.TwiML.Messaging
Imports Twilio.Types

Public Class TwilioHandler

    Private MainForm As Form_Main
    Private accSID As String
    Private authToken As String
    Private fromNumber As String

    Public Sub New(ByRef mf As Form_Main, sid As String, auth As String, fromNumber As String)

        Me.MainForm = mf
        Me.accSID = sid
        Me.authToken = auth
        Me.fromNumber = fromNumber

        mf.Log("Initializing Twilio service.")
        TwilioClient.Init(sid, auth)

    End Sub

    Public Sub SendSMS(toNumber As String, msg As String)

        Dim toNum = New PhoneNumber(toNumber)
        Dim message = MessageResource.Create(toNumber, from:=New PhoneNumber(fromNumber), body:=msg)

    End Sub


End Class
