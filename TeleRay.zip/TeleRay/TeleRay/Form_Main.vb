﻿
Imports Microsoft.Win32
Imports System.Deployment.Application
Imports System.Timers
Imports Twilio.Rest.Api.V2010.Account.Usage.Record

Public Class Form_Main
    Private twHandler As TwilioHandler = Nothing
    Private gmailHander As GmailHandler = Nothing
    Private regKeyTw As RegistryKey = Nothing
    Private regKeyGm As RegistryKey = Nothing

    Private mailCheckTimer As Timer
    Private detectedMessages As New List(Of String)

    Private Sub Form_Main_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'fetch twilio auth params from registry, if not found create

        If ApplicationDeployment.IsNetworkDeployed Then
            VersionLabel.Text = "TeleRay " & ApplicationDeployment.CurrentDeployment.CurrentVersion.ToString
        Else
            VersionLabel.Text = "TeleRay Debug"
        End If

        If My.Settings.WaitTime = 0 Then My.Settings.WaitTime = 60000
        mailCheckTimer = New Timer(My.Settings.WaitTime)

        AddHandler mailCheckTimer.Elapsed, New ElapsedEventHandler(AddressOf MailCheckTimerElapsed)

        LogList.HeaderStyle = ColumnHeaderStyle.None

        StartButton.Enabled = False

        Log("Fetching credentials from registry.")
        If InitTwHandler() And InitGmHandler() Then
            Log("Ready.", Color.Blue)
            StartButton.Enabled = True
        End If

    End Sub

    Private Sub MailCheckTimerElapsed()

        Log("Checking new emails.")

        Dim newEmails As List(Of String) = gmailHander.FetchNewMail(True)

        For Each eMail In newEmails
            If eMail.ToUpper.Contains(My.Settings.SearchText.ToUpper) Then
                If detectedMessages.Contains(eMail.Split("#")(2)) Then Continue For
                Log("New voicemail found! Sending SMS.",, 2)
                twHandler.SendSMS(My.Settings.SendToNumber, "You have a new voicemail!")
                If detectedMessages.Count > 30 Then detectedMessages.Clear()
                detectedMessages.Add(eMail.Split("#")(2))
            End If
        Next

    End Sub

    Private Function InitTwHandler() As Boolean
        Try
            regKeyTw = My.Computer.Registry.CurrentUser.OpenSubKey("Software\TeleRay\Twilio", True)
            If IsNothing(regKeyTw) Then
                My.Computer.Registry.CurrentUser.CreateSubKey("Software\TeleRay\Twilio")
                regKeyTw = My.Computer.Registry.CurrentUser.OpenSubKey("Software\TeleRay\Twilio", True)
                Log("Please configure Twilio authentication in settings.", Color.Red, 2)
                Return False
            Else
                Dim sid As String = regKeyTw.GetValue("SID", "notfound")
                Dim at As String = regKeyTw.GetValue("AuthToken", "notfound")

                If sid = "notfound" Or at = "notfound" Then
                    Log("Please configure Twilio authentication in settings.", Color.Red, 2)
                    Return False
                Else
                    twHandler = New TwilioHandler(Me, sid, at, My.Settings.FromNumber)
                    Return True
                End If
            End If
        Catch ex As Exception
            Log("There was an error connecting to Twilio.", Color.Red, 2)
            Return False
        End Try
    End Function

    Private Function InitGmHandler() As Boolean
        Try
            'fetch gmail auth params from registry, if not found create
            regKeyGm = My.Computer.Registry.CurrentUser.OpenSubKey("Software\TeleRay\Gmail", True)
            If IsNothing(regKeyGm) Then
                My.Computer.Registry.CurrentUser.CreateSubKey("Software\TeleRay\Gmail")
                regKeyGm = My.Computer.Registry.CurrentUser.OpenSubKey("Software\TeleRay\Gmail", True)
                Log("Please configure Gmail authentication in settings.", Color.Red, 2)
                Return False
            Else
                Dim appKey As String = regKeyGm.GetValue("AppKey", "notfound")
                Dim email As String = regKeyGm.GetValue("Email", "notfound")
                If appKey = "notfound" Or email = "notfound" Then
                    Log("Please configure Gmail authentication in settings.", Color.Red, 2)
                    Return False
                Else
                    gmailHander = New GmailHandler(Me, email, appKey)
                    Return True
                End If
            End If
        Catch ex As Exception
            Log("There was an error connecting to Gmail.", Color.Red, 2)
            Return False
        End Try
    End Function

    Private Sub SettingsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SettingsToolStripMenuItem.Click
        Dim sf As New Form_Settings(regKeyTw, regKeyGm)
        If sf.ShowDialog() = DialogResult.OK Then
            If Not IsNothing(gmailHander) Then gmailHander.Close()
            Log("Reconnecting.")
            If InitTwHandler() And InitGmHandler() Then
                StartButton.Enabled = True
            End If
            If mailCheckTimer.Enabled Then
                mailCheckTimer.Stop()
                mailCheckTimer.Enabled = False
                mailCheckTimer.Interval = My.Settings.WaitTime
                mailCheckTimer.Enabled = True
                mailCheckTimer.Start()
            End If

        End If
    End Sub

    Public Sub Log(msg As String, Optional color As Color = Nothing, Optional indent As Integer = 0)
        Me.Invoke(Sub()
                      Dim ind As String = ""
                      For i As Integer = 0 To indent * 3
                          ind = ind & " "
                      Next
                      Dim litem As New ListViewItem("[" & DateTime.Now.ToString("HH:mm:ss") & "] " & ind & msg)
                      If color = Nothing Then color = Color.Black
                      litem.ForeColor = color
                      LogList.Items.Add(litem)
                      LogList.EnsureVisible(LogList.Items.Count - 1)
                      LogList.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent)
                  End Sub)
    End Sub

    Private Sub Form_Main_Closing(sender As Object, e As EventArgs) Handles Me.FormClosing
        mailCheckTimer.Stop()
        If Not IsNothing(gmailHander) Then
            gmailHander.Close()
        End If
    End Sub

    Private Sub StartButton_Click(sender As Object, e As EventArgs) Handles StartButton.Click
        If mailCheckTimer.Enabled Then
            Log("Service Stopped.", Color.Red)
            mailCheckTimer.Stop()
            StartButton.Text = "Start"
        Else
            Log("Service Started.", Color.Green)
            mailCheckTimer.Start()
            StartButton.Text = "Stop"
        End If

    End Sub

    Private Sub Main_Form_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        If Me.WindowState = FormWindowState.Minimized Then
            NotifyIcon1.Visible = True
            Me.Hide()
            NotifyIcon1.BalloonTipText = "TeleRay is still running"
            NotifyIcon1.ShowBalloonTip(500)
        End If
    End Sub

    Private Sub NotifyIcon1_DoubleClick(sender As Object, e As EventArgs) Handles NotifyIcon1.DoubleClick
        Me.Show()
        Me.WindowState = FormWindowState.Normal
        NotifyIcon1.Visible = True
    End Sub

End Class
