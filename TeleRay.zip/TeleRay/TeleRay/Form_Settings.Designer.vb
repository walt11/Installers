﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Settings
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_Settings))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SIDTextBox = New System.Windows.Forms.TextBox()
        Me.SaveButton = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TokenTextBox = New System.Windows.Forms.TextBox()
        Me.EmailTextBox = New System.Windows.Forms.TextBox()
        Me.AppPassTextBox = New System.Windows.Forms.TextBox()
        Me.CancelButton = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.WaitTimeTextBox = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TwNumberTextBox = New System.Windows.Forms.TextBox()
        Me.SMSToTextBox = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.SearchTextBox = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.SMSTextBox = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(48, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(58, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Twilio SID:"
        '
        'SIDTextBox
        '
        Me.SIDTextBox.Location = New System.Drawing.Point(112, 6)
        Me.SIDTextBox.Name = "SIDTextBox"
        Me.SIDTextBox.Size = New System.Drawing.Size(323, 20)
        Me.SIDTextBox.TabIndex = 1
        '
        'SaveButton
        '
        Me.SaveButton.Location = New System.Drawing.Point(374, 264)
        Me.SaveButton.Name = "SaveButton"
        Me.SaveButton.Size = New System.Drawing.Size(75, 23)
        Me.SaveButton.TabIndex = 10
        Me.SaveButton.Text = "Save"
        Me.SaveButton.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(32, 32)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(74, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Twilio Token: "
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(42, 90)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(64, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Gmail Email:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(22, 114)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(84, 13)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Gmail App Pass:"
        '
        'TokenTextBox
        '
        Me.TokenTextBox.Location = New System.Drawing.Point(112, 29)
        Me.TokenTextBox.Name = "TokenTextBox"
        Me.TokenTextBox.Size = New System.Drawing.Size(323, 20)
        Me.TokenTextBox.TabIndex = 2
        '
        'EmailTextBox
        '
        Me.EmailTextBox.Location = New System.Drawing.Point(112, 87)
        Me.EmailTextBox.Name = "EmailTextBox"
        Me.EmailTextBox.Size = New System.Drawing.Size(172, 20)
        Me.EmailTextBox.TabIndex = 4
        '
        'AppPassTextBox
        '
        Me.AppPassTextBox.Location = New System.Drawing.Point(112, 111)
        Me.AppPassTextBox.Name = "AppPassTextBox"
        Me.AppPassTextBox.Size = New System.Drawing.Size(172, 20)
        Me.AppPassTextBox.TabIndex = 5
        '
        'CancelButton
        '
        Me.CancelButton.Location = New System.Drawing.Point(293, 264)
        Me.CancelButton.Name = "CancelButton"
        Me.CancelButton.Size = New System.Drawing.Size(75, 23)
        Me.CancelButton.TabIndex = 11
        Me.CancelButton.Text = "Cancel"
        Me.CancelButton.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(48, 155)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(58, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Wait Time:"
        '
        'WaitTimeTextBox
        '
        Me.WaitTimeTextBox.Location = New System.Drawing.Point(112, 152)
        Me.WaitTimeTextBox.Name = "WaitTimeTextBox"
        Me.WaitTimeTextBox.Size = New System.Drawing.Size(45, 20)
        Me.WaitTimeTextBox.TabIndex = 6
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(163, 159)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(23, 13)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "min"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(29, 184)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(77, 13)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Send SMS To:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(29, 58)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(77, 13)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "Twilio Number:"
        '
        'TwNumberTextBox
        '
        Me.TwNumberTextBox.Location = New System.Drawing.Point(112, 55)
        Me.TwNumberTextBox.Name = "TwNumberTextBox"
        Me.TwNumberTextBox.Size = New System.Drawing.Size(97, 20)
        Me.TwNumberTextBox.TabIndex = 3
        '
        'SMSToTextBox
        '
        Me.SMSToTextBox.Location = New System.Drawing.Point(112, 178)
        Me.SMSToTextBox.Name = "SMSToTextBox"
        Me.SMSToTextBox.Size = New System.Drawing.Size(97, 20)
        Me.SMSToTextBox.TabIndex = 7
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(38, 211)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(68, 13)
        Me.Label9.TabIndex = 17
        Me.Label9.Text = "Search Text:"
        '
        'SearchTextBox
        '
        Me.SearchTextBox.Location = New System.Drawing.Point(112, 208)
        Me.SearchTextBox.Name = "SearchTextBox"
        Me.SearchTextBox.Size = New System.Drawing.Size(172, 20)
        Me.SearchTextBox.TabIndex = 8
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(49, 237)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(57, 13)
        Me.Label10.TabIndex = 19
        Me.Label10.Text = "SMS Text:"
        '
        'SMSTextBox
        '
        Me.SMSTextBox.Location = New System.Drawing.Point(112, 234)
        Me.SMSTextBox.Name = "SMSTextBox"
        Me.SMSTextBox.Size = New System.Drawing.Size(323, 20)
        Me.SMSTextBox.TabIndex = 9
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.Label11.Location = New System.Drawing.Point(12, 277)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(118, 13)
        Me.Label11.TabIndex = 20
        Me.Label11.Text = "Created by John Walter"
        '
        'Form_Settings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(461, 299)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.SMSTextBox)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.SearchTextBox)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.SMSToTextBox)
        Me.Controls.Add(Me.TwNumberTextBox)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.WaitTimeTextBox)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.CancelButton)
        Me.Controls.Add(Me.AppPassTextBox)
        Me.Controls.Add(Me.EmailTextBox)
        Me.Controls.Add(Me.TokenTextBox)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.SaveButton)
        Me.Controls.Add(Me.SIDTextBox)
        Me.Controls.Add(Me.Label1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form_Settings"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Settings"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents SIDTextBox As TextBox
    Friend WithEvents SaveButton As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents TokenTextBox As TextBox
    Friend WithEvents EmailTextBox As TextBox
    Friend WithEvents AppPassTextBox As TextBox
    Friend WithEvents CancelButton As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents WaitTimeTextBox As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents TwNumberTextBox As TextBox
    Friend WithEvents SMSToTextBox As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents SearchTextBox As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents SMSTextBox As TextBox
    Friend WithEvents Label11 As Label
End Class
