﻿Imports Microsoft.Win32

Public Class Form_Settings

    Private regKeyTw As RegistryKey
    Private regKeyGm As RegistryKey

    Public Sub New(ByRef rkTw As RegistryKey, ByRef rkGm As RegistryKey)

        ' This call is required by the designer.
        InitializeComponent()

        Me.regKeyTw = rkTw
        Me.regKeyGm = rkGm

        SIDTextBox.Text = regKeyTw.GetValue("SID")
        TokenTextBox.Text = regKeyTw.GetValue("AuthToken")

        EmailTextBox.Text = regKeyGm.GetValue("Email")
        AppPassTextBox.Text = regKeyGm.GetValue("AppKey")

        TwNumberTextBox.Text = My.Settings.FromNumber
        WaitTimeTextBox.Text = (My.Settings.WaitTime / 60000).ToString
        SMSToTextBox.Text = My.Settings.SendToNumber
        SearchTextBox.Text = My.Settings.SearchText
        SMSTextBox.Text = My.Settings.SMSMessage


        ' Add any initialization after the InitializeComponent() call.

    End Sub

    Private Sub CancelButton_Click(sender As Object, e As EventArgs) Handles CancelButton.Click
        Me.Close()
    End Sub

    Private Sub SaveButton_Click(sender As Object, e As EventArgs) Handles SaveButton.Click
        regKeyTw.SetValue("SID", SIDTextBox.Text)
        regKeyTw.SetValue("AuthToken", TokenTextBox.Text)

        regKeyGm.SetValue("Email", EmailTextBox.Text)
        regKeyGm.SetValue("AppKey", AppPassTextBox.Text)

        My.Settings.FromNumber = TwNumberTextBox.Text
        My.Settings.WaitTime = CDbl(WaitTimeTextBox.Text) * 60000
        My.Settings.SendToNumber = SMSToTextBox.Text
        My.Settings.SearchText = SearchTextBox.Text
        My.Settings.SMSMessage = SMSTextBox.Text

        My.Settings.Save()

        Me.DialogResult = DialogResult.OK
        Me.Close()

    End Sub

End Class