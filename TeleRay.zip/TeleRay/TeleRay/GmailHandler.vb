﻿Imports EAGetMail


Public Class GmailHandler

    Private MainForm As Form_Main
    Private mServer As MailServer
    Private mClient As MailClient

    Public Sub New(ByRef mf As Form_Main, username As String, apppass As String)

        Me.MainForm = mf

        mf.Log("Connecting to Gmail.")

        mServer = New MailServer("imap.gmail.com", username, apppass, ServerProtocol.Imap4)
        mServer.SSLConnection = True
        mServer.Port = 993

        mClient = New MailClient("TryIt")
        mClient.Connect(mServer)

    End Sub

    Public Sub Close()
        mClient.Quit()
    End Sub

    Public Function FetchNewMail(markAsRead As Boolean) As List(Of String)

        Dim mailList As New List(Of String)

        mClient.GetMailInfosParam.Reset()
        mClient.GetMailInfosParam.GetMailInfosOptions = GetMailInfosOptionType.NewOnly

        Dim infos As MailInfo() = mClient.GetMailInfos()

        For i As Integer = 0 To infos.Length - 1
            Dim info As MailInfo = infos(i)

            Dim mMail As Mail = mClient.GetMail(info)

            mailList.Add(mMail.From.ToString & "#" & mMail.Subject & "#" & mMail.SentDate.ToString)

            If markAsRead Then
                If Not info.Read Then
                    mClient.MarkAsRead(info, True)
                End If
            End If

        Next

        Return mailList

    End Function

End Class
